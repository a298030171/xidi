<?php

    $now = $_POST["now"];
    $d = $_POST["d"];

    echo ($d - $now);
?>