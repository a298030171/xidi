import "../libs/jquery-1.12.4.js";
import "../libs/jquery.cookie.js";

import {ShoppingCar} from "./shoppingcar.JS"
import { Islogin } from "./Islogin.js";
import { Tocar } from "./tocar.js";

new ShoppingCar();
new Islogin();
new Tocar();