var socket_local_port='http://localhost:3000';
var socket_http_port='http://47.110.139.198:80';
var socket_https_port='https://uncle9.top:443';
var port = socket_local_port;